/*
NOME: Gabriel Siqueira Nascimento Silva
RA: 818114786
TURMA: ADS1BN-MCA
*/

CREATE DATABASE `agendasys`;

USE `agendasys`;

CREATE TABLE `pessoa` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`nome` varchar(100) NOT NULL,
	`endereco` varchar(100) NOT NULL,
	`telefone` char(20) NOT NULL,
	`email` varchar(100) NOT NULL UNIQUE,
	PRIMARY KEY (`id`)
);

INSERT INTO `pessoa` (`id`, `nome`, `endereco`, `telefone`, `email`) VALUES (0, 'Gabriel Siqueira', 'Estrada Itaquera-Guaianazes', '+55(11)95101-5517', 'pura360@gmail.com');

SELECT * FROM pessoa;