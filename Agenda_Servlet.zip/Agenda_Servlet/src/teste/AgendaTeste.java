package teste;

import java.sql.Connection;
import java.sql.SQLException;

import dao.ConnectionFactory;
import jframe.AgendaJF;

public class AgendaTeste {

	public static void main(String[] args) {
		
		try {
			Connection connection = ConnectionFactory.obtemConexao();
			new AgendaJF(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
