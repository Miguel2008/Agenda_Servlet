package model;

public class Agenda {
	private int idPessoa;
	private String nome;
	private String endereco;
	private String telefone;
	private String email;
	
	// CONSTRUTOR VAZIO
	public Agenda() {
		
	}
	
	// CONTRUTOR COM O PARAMETRO S� COM ID
	public Agenda(int idPessoa) {
		this.idPessoa = idPessoa;
	}
	   
	// CONTRUTOR SEM O PARAMETRO ID
	public Agenda(String nome, String endereco, String telefone, String email) {
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
		this.email = email;
	}
	   
	// CONTRUTOR COMPLETO
	public Agenda(int idPessoa, String nome, String endereco, String telefone, String email) {
		this.idPessoa = idPessoa;
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
		this.email = email;
	}
	
	// IDPESSOA
	public int getIdPessoa() {
		return idPessoa;
	}

	public void setIdPessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}
	
	// NOME
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	// ENDERECO
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	// TELEFONE
	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	// EMAIL
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
