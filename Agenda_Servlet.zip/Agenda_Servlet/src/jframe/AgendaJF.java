package jframe;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Agenda;
import service.AgendaService;

public class AgendaJF extends JFrame implements ActionListener{
  
   private static final long serialVersionUID = 1L;
   private JLabel titulo, nome, endereco, telefone, email;
   private JButton registrar, pesquisar, alterar, deletar, limpar, sair;
   private JTextField txtID, txtNome, txtEndereco, txtTelefone, txtEmail;
   private ImageIcon imagemVassoura, imagemLupa, imagemSair;
   public AgendaJF(Connection conn){
      super("AgendaJF");
      Container caixa = getContentPane();
     
   //Forumulario
   
      titulo = new JLabel("AGENDA");
      titulo.setBounds(230, 35, 200, 35);
      
      txtID = new JTextField("");
      txtID.setBounds(120, 50, 50, 30);
      
      nome = new JLabel("Nome:");
      nome.setBounds(40, 100, 150, 35);
      
      txtNome = new JTextField("");
      txtNome.setBounds(120, 100, 300, 30);
      
      endereco = new JLabel("Endere�o:");
      endereco.setBounds(40, 150, 150, 35);
      
      txtEndereco = new JTextField("");
      txtEndereco.setBounds(120, 150, 350, 30);
      
      telefone = new JLabel("Telefone:");
      telefone.setBounds(40, 200, 150, 35);
      
      txtTelefone = new JTextField("");
      txtTelefone.setBounds(120, 200, 250, 30);
      
      email = new JLabel("Email:");
      email.setBounds(40, 250, 150, 35);
      
      txtEmail = new JTextField("");
      txtEmail.setBounds(120, 250, 350, 30);
      
    // BOT�ES      
      registrar = new JButton("Registrar");
      registrar.setBounds(160, 320, 90, 30);
      registrar.setBackground(new Color(217, 217, 217));
      
      alterar = new JButton("Alterar");
      alterar.setBounds(270, 320, 90, 30);
      alterar.setBackground(new Color(217, 217, 217));
      
      deletar = new JButton("Deletar");
      deletar.setBounds(380, 320, 90, 30);
      deletar.setBackground(new Color(217, 217, 217));
      
      imagemLupa = new ImageIcon(getClass().getResource("../imagens/lupa.png"));
      pesquisar = new JButton(imagemLupa);
      pesquisar.setBounds(10, 10, 30, 30);
      pesquisar.setBackground(new Color(217, 217, 217));
      
      imagemVassoura = new ImageIcon(getClass().getResource("../imagens/vassoura.png"));
      limpar = new JButton(imagemVassoura);
      limpar.setBounds(50, 10, 30, 30);
      limpar.setBackground(new Color(217, 217, 217));
      
      imagemSair = new ImageIcon(getClass().getResource("../imagens/sair.png"));
      sair = new JButton(imagemSair);
      sair.setBounds(10, 320, 30, 30);
      sair.setBackground(new Color(217, 217, 217));
      
            
      // JLabel, JText      
      caixa.add(titulo);
      caixa.add(nome);
      caixa.add(txtNome);
      caixa.add(endereco);
      caixa.add(txtEndereco);
      caixa.add(telefone);
      caixa.add(txtTelefone);
      caixa.add(email);
      caixa.add(txtEmail);
      
      //BOTOES
      caixa.add(registrar);
      caixa.add(pesquisar);
      caixa.add(alterar);
      caixa.add(deletar);
      caixa.add(limpar);
      caixa.add(sair);
      
   // ESCONDENDO OS BOT�ES
      alterar.setVisible(false);
      deletar.setVisible(false);
      
   // A��O DE CLIQUE NO BOT�O
      registrar.addActionListener(this);
      pesquisar.addActionListener(this);
      alterar.addActionListener(this);
      deletar.addActionListener(this);
      limpar.addActionListener(this);
      sair.addActionListener(this);
      
   // CONFIGURA��O DA TELA
      setSize(500,400);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setResizable(false);
      setLayout(null);
      setLocationRelativeTo(null);
      setVisible(true);
      
   }
   
   // FUN��ES DOS BOT�ES
   public void actionPerformed(ActionEvent e){
	   AgendaService agendaService = new AgendaService();
	   
      // BOT�O REGISTRAR
      if(e.getSource()==registrar){
    	  //Agenda pessoa = new Agenda();
    	  
         if (txtNome.getText().trim().equals("") || txtEndereco.getText().trim().equals("") || txtTelefone.getText().trim().equals("") || txtEmail.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Por Favor\n\nPreencha todos os campos.");
         } else {
            Agenda agenda = new Agenda(txtNome.getText(),txtEndereco.getText(),txtTelefone.getText(), txtEmail.getText());      
            //agendaDAO.incluir(conn);
            agendaService.inserir(agenda);
         
            txtNome.setText("");
            txtEndereco.setText("");
            txtTelefone.setText("");
            txtEmail.setText("");
            JOptionPane.showMessageDialog(null,"Inserido com Sucesso!!");
         }
      
      // BOT�O PESQUISAR 
         
      }else if(e.getSource()==pesquisar){
    	 String sId = JOptionPane.showInputDialog("Digite o ID");
    	 int id;
    	 
    	 
         if (sId == null){ 
        	 id = 0;
         }else{
        	id = Integer.parseInt(sId);
            //int idPessoa = id;
            Agenda agenda = new Agenda(id);
			agendaService.pesquisar(agenda);
            
            txtID.setText(""+agenda.getIdPessoa());
            txtNome.setText(agenda.getNome());
            txtEndereco.setText(agenda.getEndereco());
            txtTelefone.setText(agenda.getTelefone());
            txtEmail.setText(agenda.getEmail());
            /*
            System.out.println(txtID.getText());
            System.out.println(txtNome.getText());
            System.out.println(txtEndereco.getText());
            System.out.println(txtTelefone.getText());
            System.out.println(txtEmail.getText());
            */
            if (txtNome.getText().equals("")){
               JOptionPane.showMessageDialog(null, "AVISO\n\nID n�o Encontrado\n");
            }else {
               registrar.setVisible(false);
               alterar.setVisible(true);
               deletar.setVisible(true);
            }
         }
      
      // BOT�O ALTERAR  
      }else if(e.getSource()==alterar){

         if (txtNome.getText().trim().equals("") && txtEndereco.getText().trim().equals("") && txtTelefone.getText().trim().equals("") && txtEmail.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Por Favor\n\nPesquise primeiro um ID\n");
         }else if (txtNome.getText().trim().equals("") || txtEndereco.getText().trim().equals("") || txtTelefone.getText().trim().equals("") || txtEmail.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"ERRO\n\nPreencha todos os Campos\n");
         }else {              
            Agenda agenda = new Agenda(Integer.parseInt(txtID.getText()), txtNome.getText(),txtEndereco.getText(),txtTelefone.getText(), txtEmail.getText());      
            agendaService.atualizar(agenda);
            
            JOptionPane.showMessageDialog(null,"Alterado!!");
            
            txtID.setText("");
            txtNome.setText("");
            txtEndereco.setText("");
            txtTelefone.setText("");
            txtEmail.setText("");
            
            registrar.setVisible(true);
            alterar.setVisible(false);
            deletar.setVisible(false);
         }
      
      // BOT�O DELETAR  
      }else if(e.getSource()==deletar){
    	  //int idPessoa = 0;
         if (txtNome.getText().trim().equals("") || txtEndereco.getText().trim().equals("") || txtTelefone.getText().trim().equals("") || txtEmail.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Por Favor\n\nPesquise primeiro um ID\n");
         }else {
            Agenda agenda = new Agenda(Integer.parseInt(txtID.getText()));
            agendaService.excluir(agenda);
         
            txtNome.setText(agenda.getNome());
            txtEndereco.setText(agenda.getEndereco());
            txtTelefone.setText(agenda.getTelefone());
            txtEmail.setText(agenda.getEmail());
            
            JOptionPane.showMessageDialog(null,"Deletado!!");
            
            registrar.setVisible(true);
            alterar.setVisible(false);
            deletar.setVisible(false);
         }
      
      // BOT�O LIMPAR   
      }else if (e.getSource() == limpar) {
         txtID.setText("");
         txtNome.setText("");
         txtEndereco.setText("");
         txtTelefone.setText("");
         txtEmail.setText("");
         
         registrar.setVisible(true);
         alterar.setVisible(false);
         deletar.setVisible(false);
      }
      
      // BOT�O SAIR
      else if (e.getSource() == sair) {
         System.exit(0);
      }
      
   }
   
}
